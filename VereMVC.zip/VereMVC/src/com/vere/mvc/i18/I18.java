package com.vere.mvc.i18;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.vere.mvc.util.CConfig;


/**
 * @author 胡杨
 */
public class I18
{
	private static ConcurrentHashMap<String,ConcurrentHashMap<String,String>> i18Map=new ConcurrentHashMap<String,ConcurrentHashMap<String,String>>();
	private static String localeLanguage="zh_CN";
	
	public static String getText(String key)
	{
		ConcurrentHashMap<String,String> bundleMap=i18Map.get(localeLanguage);
		return bundleMap.get(key);
	}
	
	public static void loadResources()
	{
		try
		{
			String currentClassPath=CConfig.getClassAbsolutePath();
			if(currentClassPath==null || "".equals(currentClassPath))
			{
				return;
			}
			
			File classDir=new File(currentClassPath);
			File[] classFiles=classDir.listFiles();
			
			//SAXReader read 
			SAXReader reader=new SAXReader();
			for(File file:classFiles)
			{
				String fileName=file.getName();
				if(fileName.startsWith(CConfig.getResourceName()) && fileName.endsWith(".xml"))
				{
					String code=fileName.substring(fileName.indexOf("_")+1,fileName.lastIndexOf("."));
					ConcurrentHashMap<String,String> bundleMap=new ConcurrentHashMap<String,String>();
					
					InputStream is=null;
					try
					{
						String filePath=CConfig.getClassAbsolutePath()+fileName;
						is=new FileInputStream(filePath);
						if(is==null)
						{
							continue;
						}
						Document doc=reader.read(is);
						List<Element> elementList=doc.selectNodes("/resources/item");
						for(Element element:elementList)
						{
							String key=element.attributeValue("key");
							String value=element.getText();
							bundleMap.put(key, value);
							i18Map.put(code,bundleMap);
						}
					} catch (Exception e)
					{
						e.printStackTrace();
					}
					finally
					{
						try {
							is.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
				
			}
			
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static String getLocaleLanguage() {
		return localeLanguage;
	}

	public static void setLocaleLanguage(String localeLanguage) {
		I18.localeLanguage = localeLanguage;
	}
	
	
}
