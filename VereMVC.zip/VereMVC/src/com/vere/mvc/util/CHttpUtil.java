package com.vere.mvc.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class CHttpUtil {      
	
	public static String license(String path,String charset)
	{                 
		boolean isException=false;
		InputStream in = null;
		StringBuilder sb=new StringBuilder();
		HttpURLConnection conn=null;
		try {
			URL uri = new URL(path);        
			conn = (HttpURLConnection) uri.openConnection();                        
			conn.setReadTimeout(20 * 1000);         
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setUseCaches(false);         
			conn.setRequestMethod("GET");     
			conn.connect();
			in=conn.getInputStream();
			
			BufferedReader br = new BufferedReader( new InputStreamReader(in,charset));
					
			String str=null;
			while ((str=br.readLine())!=null) {
				sb.append(str);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			isException=true;
			
		} finally {
			try {
				if (in != null) {
					in.close();
				}
				if(conn!=null)
				{
					conn.disconnect();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return sb.toString();
		
	}          
	
}

