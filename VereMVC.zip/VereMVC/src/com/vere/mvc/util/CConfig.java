package com.vere.mvc.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.vere.mvc.model.ActionItem;
import com.vere.mvc.model.InterceptorActionItem;
import com.vere.mvc.model.InterceptorItem;
import com.vere.mvc.model.ResultItem;

public class CConfig
{
	private static ConcurrentHashMap<String,ActionItem>  vereMVCMap=new ConcurrentHashMap<String,ActionItem>();
	private static ConcurrentHashMap<String,String>  constantsMap=new ConcurrentHashMap<String,String>();
	private static List<InterceptorItem>  interceptorList=new ArrayList<InterceptorItem>();
	private static String classAbsolutePath="";
	public static int licenseCount=1;
	
	public static String getActionClass(String actionName)
	{
		ActionItem actionItem=vereMVCMap.get(actionName);
		if(actionItem==null)
		{
			return "";
		}
		else
		{
			return actionItem.getClazz();
		}
		
	}
	
	public static String getResultPath(String actionName,String resultName)
	{
		ActionItem actionItem=vereMVCMap.get(actionName);
		
		ResultItem resultItem=actionItem.getResultItemMap().get(resultName);
		
		return resultItem.getPath();
		
	}
	
	public static boolean isExit(String actionName)
	{
		ActionItem actionItem=vereMVCMap.get(actionName);
		if(actionItem==null || actionName==null || "".equals(actionName))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public static ResultItem getResultItem(String actionName,String resultName)
	{
		ActionItem actionItem=vereMVCMap.get(actionName);
		
		ResultItem resultItem=actionItem.getResultItemMap().get(resultName);
		
		return resultItem;
		
	}
	
	public static  void loadResources()
	{
		
		String currentClassPath=CConfig.getClassAbsolutePath();
		if(currentClassPath==null || "".equals(currentClassPath))
		{
			return;
		}
		
		InputStream is=null;
		ConcurrentHashMap<String,ActionItem>  vereMVCCacheMap=new ConcurrentHashMap<String,ActionItem>();
		ConcurrentHashMap<String,String>  constantsCacheMap=new ConcurrentHashMap<String,String>();
		List<InterceptorItem>  interceptorCacheList=new ArrayList<InterceptorItem>();
		try
		{
			
			
			
			
			//SAXReader read 
			SAXReader reader=new SAXReader();
			String filePath=CConfig.getClassAbsolutePath()+"VereMVC.xml";
			is=new FileInputStream(filePath);
			
			if(is==null)
			{
				return;
			}
			
			Document doc=reader.read(is);
			List<Element> elementList=doc.selectNodes("/VereMVC/action");
			for(Element element:elementList)
			{
				ActionItem actionItem=new ActionItem();
				String name=element.attributeValue("name");
				String clazz=element.attributeValue("class");
				actionItem.setName(name);
				actionItem.setClazz(clazz);
				
				ConcurrentHashMap<String,ResultItem> resultItemMap=new ConcurrentHashMap<String,ResultItem>();
				
				List<Element> elementChildList=element.elements();
				for(Element elementChild:elementChildList)
				{
					ResultItem resultItem=new ResultItem();
					String resultName=elementChild.attributeValue("name");
					String type=elementChild.attributeValue("type");
					String path=elementChild.getText();
					resultItem.setName(name);
					resultItem.setType(type);
					resultItem.setPath(path);
					
					resultItemMap.put(resultName, resultItem);
				}
				
				actionItem.setResultItemMap(resultItemMap);
				
				vereMVCCacheMap.put(name, actionItem);
			}
			
			elementList=doc.selectNodes("/VereMVC/constant");
			for(Element element:elementList)
			{
				String name=element.attributeValue("name");
				String value=element.attributeValue("value");
				constantsCacheMap.put(name, value);
			}
			
			elementList=doc.selectNodes("/VereMVC/interceptor");
			for(Element element:elementList)
			{
				InterceptorItem interceptorItem=new InterceptorItem();
				String name=element.attributeValue("name");
				String clazz=element.attributeValue("class");
				interceptorItem.setName(name);
				interceptorItem.setClazz(clazz);
				
				ConcurrentHashMap<String,InterceptorActionItem> interceptorItemMap=new ConcurrentHashMap<String,InterceptorActionItem>();
				
				List<Element> elementChildList=element.elements();
				for(Element elementChild:elementChildList)
				{
					InterceptorActionItem interceptorActionItem=new InterceptorActionItem();
					String interceptorName=elementChild.attributeValue("name");
					interceptorActionItem.setName(interceptorName);
					
					interceptorItemMap.put(interceptorName, interceptorActionItem);
				}
				
				interceptorItem.setInterceptorActionItemMap(interceptorItemMap);
				
				interceptorCacheList.add(interceptorItem);
			}
			
			vereMVCMap=vereMVCCacheMap;
			constantsMap=constantsCacheMap;
			interceptorList=interceptorCacheList;
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	

	public static List<InterceptorItem> getInterceptorList() {
		return interceptorList;
	}

	public static String getCharset() {
		String charset=constantsMap.get("charset");
		if(charset==null || "".equals(charset.trim()))
		{
			charset="utf-8";
		}
		return charset;
	}

	public static void setCharset(String charset) {
		constantsMap.put("charset", charset);
	}
	
	public static boolean isDevelopMode()
	{
		String developMode=constantsMap.get("developMode");
		if("true".equals(developMode))
		{
			return true;
		}
		
		return false;
			
	}
	

	public static long getFileUploadMaxSize() {
		String fileUploadMaxSize=constantsMap.get("fileUploadMaxSize");
		if(fileUploadMaxSize==null || "".equals(fileUploadMaxSize.trim()))
		{
			fileUploadMaxSize="10485760";
		}
		return Long.parseLong(fileUploadMaxSize);
	}

	public static void setFileUploadMaxSize(long fileUploadMaxSize) {
		constantsMap.put("fileUploadMaxSize", String.valueOf(fileUploadMaxSize));
	}
	

	public static String getLanguage() {
		String language=constantsMap.get("language");
		if(language==null || "".equals(language.trim()))
		{
			language="zh_CN";
		}
		return language;
	}

	public static void setLanguage(String language) {
		constantsMap.put("language", language);
	}
	

	public static String getResourceName() {
		String resourceName=constantsMap.get("resourceName");
		if(resourceName==null || "".equals(resourceName.trim()))
		{
			resourceName="message";
		}
		return resourceName;
	}

	public static void setResourceName(String resourceName) {
		constantsMap.put("resourceName", resourceName);
	}
	

	public static String getClassAbsolutePath() {
		return classAbsolutePath;
	}

	public static void setClassAbsolutePath(String classAbsolutePathNew) {
		classAbsolutePath=classAbsolutePathNew;
	}
	
	public static String getReLoadConfigXmlTime() {
		String reLoadConfigXmlTime=constantsMap.get("reLoadConfigXmlTime");
		if(reLoadConfigXmlTime==null || "".equals(reLoadConfigXmlTime.trim()))
		{
			reLoadConfigXmlTime="1000";
		}
		return reLoadConfigXmlTime;
	}

	public static void setReLoadConfigXmlTime(String reLoadConfigXmlTime) {
		constantsMap.put("reLoadConfigXmlTime", reLoadConfigXmlTime);
	}
	
}
