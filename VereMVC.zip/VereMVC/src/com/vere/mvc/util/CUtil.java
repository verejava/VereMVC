package com.vere.mvc.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;


public class CUtil {

	public static String getBasePath(HttpServletRequest request)
	{
		String path = request.getContextPath();
		String basePath = request.getScheme()+"://"+getDomain(request)+":"+request.getServerPort()+path+"/";
		return basePath;
	}
	
	public static String getBaseURI(HttpServletRequest request)
	{
		String basePath = request.getScheme()+"://"+ getDomain(request)+request.getRequestURI();
		return basePath;
	}
	
	
	public static String getCurrentFullPath(HttpServletRequest request)
	{
		String url = request.getScheme()+"://"+ getDomain(request)+request.getRequestURI()+"?"+request.getQueryString();
		return url;
	}
	
	
	public static String getDomain(HttpServletRequest request)
	{
		String domain=request.getServerName();
    	domain=domain.toLowerCase();
    	int startPointIndex=domain.indexOf(".");
    	int endPointIndex=domain.lastIndexOf(".");
		return domain;
	}
	
	
	public static String getReadPath(HttpServletRequest request)
	{
		String path = request.getRealPath("/");
		return path;
	}
	

	
	//判断浏览器类型
	public static boolean isWindows(HttpServletRequest request){
		String ie=request.getHeader("User-Agent"); //得到浏览器等相关信息
		if(ie.indexOf("MSIE")!=-1)   //这里是msie 即微软 ie浏览器
		{
			return true;
		}
		return false;
	}
	
	
	public static String encode(String str)
	{
		return encode(str,"utf-8");
	}
	
	public static String encode(String str,String charset)
	{
		try {
			return URLEncoder.encode(str,charset);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return str;
	}
	
	public static String decode(String str)
	{
		return decode(str,"utf-8");
	}
	
	public static String decode(String str,String charset)
	{
		try {
			return URLDecoder.decode(str,charset);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return str;
	}
	
	public static  boolean isFileUpload(HttpServletRequest request)
	{
		String contentType=request.getContentType();
		if(contentType!=null&&contentType.contains("multipart"))
		{
			return true;
		}
		return false;
	}
	
	
}
