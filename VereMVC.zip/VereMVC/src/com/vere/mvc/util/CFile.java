package com.vere.mvc.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class CFile {
	public static void save(File file, String fileName) {
		InputStream in = null;
		OutputStream os = null;
		try {
			if (file != null) {
				// 创建目录路径
				String dir = fileName.substring(0, fileName.lastIndexOf(File.separatorChar));
				if (!fileExists(dir)) {
					makeDir(dir, true);
				}
				// 构建一个文件输入流
				in = new FileInputStream(file);
				os = new FileOutputStream(fileName);
				// 将上传到temp目录的文件重新写入到 upload文件夹中
				byte[] buffer = new byte[1024];
				int length = 0;
				while ((length = in.read(buffer)) != -1) {
					os.write(buffer, 0, length);
				}
				os.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
				if (os != null) {
					os.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
	
	public static void save(InputStream in, String fileName) {
		if(in==null)
		{
			return;
		}
		OutputStream os = null;
		try {
				// 创建目录路径
				String dir = fileName.substring(0, fileName.lastIndexOf(File.separatorChar));
				if (!fileExists(dir)) {
					makeDir(dir, true);
				}
				// 构建一个文件输入流
				os = new FileOutputStream(fileName);
				// 将上传到temp目录的文件重新写入到 upload文件夹中
				byte[] buffer = new byte[1024];
				int length = 0;
				while ((length = in.read(buffer)) != -1) {
					os.write(buffer, 0, length);
				}
				os.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
					in=null;
				}
				if (os != null) {
					os.close();
					os=null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public static boolean fileExists(String _sPathName) {
		File file = new File(_sPathName);
		return file.exists();
	}

	public static String extractFileName(String _sFilePathName) {
		int nPos = _sFilePathName.lastIndexOf(File.separatorChar);
		return _sFilePathName.substring(nPos + 1);
	}

	public static boolean deleteFile(String _sFilePathName) {
		File file = new File(_sFilePathName);
		if (fileExists(_sFilePathName) && file.isFile()) {
			return file.delete();
		}
		return false;
	}

	public static boolean makeDir(String _sDir, boolean _bCreateParentDir) {
		File file = new File(_sDir);
		file.setWritable(true);
		if (_bCreateParentDir) {
			return file.mkdirs();
		} else {
			return file.mkdir();
		}

	}
	
	public static void makeFile(String filePath) {
		File file = new File(filePath);
		file.setWritable(true);
		if(!file.exists())
		{
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public static boolean deleteDir(String _sDir) {
		return deleteDir(_sDir, false);
	}

	public static boolean deleteDir(String _sDir, boolean _bDeleteChildren) {
		File file = new File(_sDir);
		if (!file.exists()) {
			return false;
		}

		if (_bDeleteChildren) {
			File[] files = file.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isDirectory()) {
					deleteDir(files[i].getAbsolutePath(), _bDeleteChildren);
				} else {
					files[i].delete();
				}
			}
		}
		return file.delete();

	}
	

}
