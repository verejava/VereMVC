
package com.vere.mvc.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.vere.mvc.ServletActionContext;
import com.vere.mvc.model.CFileItem;

public class CParam
{

    public CParam()
    {
    	
    }


    public static String getString(HttpServletRequest httpservletrequest, String s)
    {
    	if(CUtil.isFileUpload(httpservletrequest))
		{
    		CFileUpload upload=ServletActionContext.getFileUpload();
    		return getString(upload, s);
		}
        return httpservletrequest.getParameter(s) != null ? httpservletrequest.getParameter(s).trim() : "";
    }



    public static String[] getArray(HttpServletRequest httpservletrequest, String s)
    {
    	if(CUtil.isFileUpload(httpservletrequest))
		{
    		CFileUpload upload=ServletActionContext.getFileUpload();
    		return getArray(upload, s);
		}
        return httpservletrequest.getParameterValues(s);
    }
    
   
    
	public static String getStrings(HttpServletRequest httpservletrequest, String s)
	{
		if(CUtil.isFileUpload(httpservletrequest))
		{
    		CFileUpload upload=ServletActionContext.getFileUpload();
    		return getStrings(upload, s);
		}
		
		String[] str_array=httpservletrequest.getParameterValues(s);
		if(str_array==null)
			return "";
		String str="";
		for(int i=0;i<str_array.length-1;i++){
			str+=str_array[i]+",";
		}
		str+=str_array[str_array.length-1];
		return str;
	}
	
	

    public static int getInt(HttpServletRequest httpservletrequest, String s)
    {
    	if(CUtil.isFileUpload(httpservletrequest))
		{
    		CFileUpload upload=ServletActionContext.getFileUpload();
    		return getInt(upload, s);
		}
    	
        if(httpservletrequest.getParameter(s) == null || httpservletrequest.getParameter(s).equals(""))
            return 0;
        else
            return Integer.parseInt(httpservletrequest.getParameter(s));
    }
    
    
    
    public static float getFloat(HttpServletRequest httpservletrequest, String s)
    {
    	if(CUtil.isFileUpload(httpservletrequest))
		{
    		CFileUpload upload=ServletActionContext.getFileUpload();
    		return getFloat(upload, s);
		}
    	
        if(httpservletrequest.getParameter(s) == null || httpservletrequest.getParameter(s).equals(""))
            return 0.00f;
        else
            return Float.parseFloat(httpservletrequest.getParameter(s));
    }
    
    public static double getDouble(HttpServletRequest httpservletrequest, String s)
    {
    	if(CUtil.isFileUpload(httpservletrequest))
		{
    		CFileUpload upload=ServletActionContext.getFileUpload();
    		return getDouble(upload, s);
		}
    	
        if(httpservletrequest.getParameter(s) == null || httpservletrequest.getParameter(s).equals(""))
            return 0.00;
        else
            return Double.parseDouble(httpservletrequest.getParameter(s));
    }
    
   

    public static long getLong(HttpServletRequest httpservletrequest, String s)
    {
    	if(CUtil.isFileUpload(httpservletrequest))
		{
    		CFileUpload upload=ServletActionContext.getFileUpload();
    		return getLong(upload, s);
		}
    	
        if(httpservletrequest.getParameter(s) == null || httpservletrequest.getParameter(s).equals(""))
            return 0L;
        else
            return Long.parseLong(httpservletrequest.getParameter(s));
    }
    
   
    ////////////////////////////////////////////////////////////////////
    
    
    public static File getFile(HttpServletRequest httpservletrequest, String s)
    {
    	if(s==null || "".equals(s))
    	{
    		return null;
    	}
    	
    	if(CUtil.isFileUpload(httpservletrequest))
		{
    		List<CFileItem> fileItemList=ServletActionContext.getFileList();
    		if(fileItemList==null || fileItemList.size()<1)
    		{
    			return null;
    		}
    		
    		for(int i=0;i<fileItemList.size();i++)
    		{
    			CFileItem fileItem=fileItemList.get(i);
    			if(s.equals(fileItem.getFieldName()))
    			{
    				return fileItem.getFile();
    			}
    		}
    		
		}
        return null;
    }
    
    public static List<File> getFileList(HttpServletRequest httpservletrequest)
    {
    	List<File> fileList=new ArrayList<File>();
    	
    	if(CUtil.isFileUpload(httpservletrequest))
		{
    		List<CFileItem> fileItemList=ServletActionContext.getFileList();
    		if(fileItemList==null || fileItemList.size()<1)
    		{
    			return null;
    		}
    		
    		for(int i=0;i<fileItemList.size();i++)
    		{
    			CFileItem fileItem=fileItemList.get(i);
    			fileList.add(fileItem.getFile());
    		}
    		
		}
        return fileList;
    }
    
    private static String getString(CFileUpload httpservletrequest, String s)
    {
    	try{
    		return httpservletrequest.getParameter(s) != null ? httpservletrequest.getParameter(s).trim() : "";
    	}catch(Exception e)
    	{
    	}
    	return "";
    }


   
    
    private static String getStrings(CFileUpload httpservletrequest, String s)
	{
		try
		{
			return httpservletrequest.getParameterValues(s);
		}catch(Exception e)
    	{
    	}
		return "";
	}
	

	private static int getInt(CFileUpload httpservletrequest,String s)
    {
    	try{
	        if(httpservletrequest.getParameter(s) == null || httpservletrequest.getParameter(s).equals(""))
	            return 0;
	        else
	            return Integer.parseInt(httpservletrequest.getParameter(s));
    	}catch(Exception e)
    	{
    	}
    	return 0;
    }
    
    
    private static float getFloat(CFileUpload httpservletrequest, String s)
    {
    	try
    	{
	        if(httpservletrequest.getParameter(s) == null || httpservletrequest.getParameter(s).equals(""))
	            return 0.00f;
	        else
	            return Float.parseFloat(httpservletrequest.getParameter(s));
    	}catch(Exception e)
    	{
    	}
    	return 0.0f;
    }
    
    private static double getDouble(CFileUpload httpservletrequest, String s)
    {
    	try
    	{
	        if(httpservletrequest.getParameter(s) == null || httpservletrequest.getParameter(s).equals(""))
	            return 0.00;
	        else
	            return Double.parseDouble(httpservletrequest.getParameter(s));
    	}catch(Exception e)
    	{
    	}
    	return 0.00;
    }
    

    private static long getLong(CFileUpload httpservletrequest, String s)
    {
    	try
    	{
	        if(httpservletrequest.getParameter(s) == null || httpservletrequest.getParameter(s).equals(""))
	            return 0L;
	        else
	            return Long.parseLong(httpservletrequest.getParameter(s));
    	}catch(Exception e)
    	{
    	}
    	return 0L;
    }
    
    private static String[] getArray(CFileUpload httpservletrequest, String s)
    {
        return httpservletrequest.getParameterValueArray(s);
    }

}
