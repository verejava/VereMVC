package com.vere.mvc.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class CFileUpload
{
	private HttpServletRequest request;
	private DiskFileItemFactory factory;
	private ServletFileUpload upload;
	//把表单里面的数据 存在map 里面
	private Map parameterMap=new HashMap();
	private List<Param> parameterList=new ArrayList<Param>();
	private List<FileItem> fileItems;
	private String encoding;
	
	
	
	public String getEncoding() {
		return encoding;
	}

	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	public static void save(File file,String fileName)
	{
		try
		{
			
			
			if(file!=null)
			{
				//构建一个文件输入流
				InputStream in=new FileInputStream(file);
				OutputStream os=new FileOutputStream(fileName);
				//将上传到temp目录的文件重新写入到 upload文件夹中
				byte[] buffer=new byte[255];
				int length=0;
				while((length=in.read(buffer))>0){
					os.write(buffer,0,length);
				}
				os.close();
				in.close();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static void save(InputStream in,String fileName)
	{
		try
		{
			
			if(in!=null)
			{
				OutputStream os=new FileOutputStream(fileName);
				//将上传到temp目录的文件重新写入到 upload文件夹中
				byte[] buffer=new byte[255];
				int length=0;
				while((length=in.read(buffer))>0){
					os.write(buffer,0,length);
				}
				os.close();
				in.close();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public CFileUpload(HttpServletRequest request) 
	{
		try
		{
			this.request=request;
			factory=new DiskFileItemFactory();
			upload=new ServletFileUpload(factory);
			upload.setSizeMax(CConfig.getFileUploadMaxSize());
			encoding=request.getCharacterEncoding();
			upload.setHeaderEncoding(encoding);
			fileItems=upload.parseRequest(request);
			Iterator<FileItem> iterator=fileItems.iterator();
			while(iterator.hasNext())
			{
				FileItem item=iterator.next();
				if(item.isFormField())
				{
					parameterMap.put(item.getFieldName(),item.getString(encoding));
					parameterList.add(new Param(item.getFieldName(),item.getString(encoding)));
				}
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public String getParameter(String key) 
	{
		return parameterMap.get(key).toString();
	}
	
	public String getParameterValues(String key) 
	{
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<parameterList.size();i++)
		{
			Param param=parameterList.get(i);
			if(key.equals(param.getKey()))
			{
				sb.append(param.getValue()+",");
			}
		}
		String value=sb.toString();
		if(value!=null&&!"".equals(value))
		{
			value=value.substring(0, value.length()-1);
		}
		return value;
	}
	
	public String[] getParameterValueArray(String key) 
	{
		String values=getParameterValues(key);
		String[] valueArray=values.split(",");
		return valueArray;
	}
	
	public void setRepository(String filePath)
	{
		factory.setRepository(new File(filePath));
	}
	
	public List<FileItem> getFiles() throws Exception
	{
		List<FileItem> fileList=new ArrayList<FileItem>();
		Iterator<FileItem> iterator=fileItems.iterator();
		while(iterator.hasNext())
		{
			FileItem item=iterator.next();
			if(!item.isFormField())
			{
				fileList.add(item);
			}
		}
		return fileList;
	}
	
	class Param{
		private String key;
		private String value;
		
		public Param(String key, String value) {
			super();
			this.key = key;
			this.value = value;
		}
		public String getKey() {
			return key;
		}
		public void setKey(String key) {
			this.key = key;
		}
		public String getValue() {
			return value;
		}
		public void setValue(String value) {
			this.value = value;
		}
		
	}
}
