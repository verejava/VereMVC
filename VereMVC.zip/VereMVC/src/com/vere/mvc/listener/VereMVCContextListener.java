package com.vere.mvc.listener;

import java.util.Set;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.vere.mvc.BackgroundTask;
import com.vere.mvc.ServletActionContext;
import com.vere.mvc.i18.I18;
import com.vere.mvc.util.CConfig;

public class VereMVCContextListener implements ServletContextListener
{
	private static BackgroundTask backgroundTask=null;
	
	@Override
	public void contextInitialized(ServletContextEvent context)
	{
		CConfig.setClassAbsolutePath(getClass().getResource("/").getPath());
		
		CConfig.loadResources();
		
		I18.loadResources();
		
		if(CConfig.isDevelopMode())
		{
			backgroundTask=new BackgroundTask();
			backgroundTask.setName("backgroundTask");
			backgroundTask.start();
		}
		
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
            	clearResource();
            }
        }));
	}


	@Override
	public void contextDestroyed(ServletContextEvent context)
	{
		clearResource();
	}
	
	private void clearResource()
	{
		destroyThreads();
		
		ServletActionContext.clearThreadLocal();
	}

	private void destroyThreads(){  
		
		if(backgroundTask!=null)
		{
			backgroundTask.setRun(false);
			backgroundTask=null;
		}
		
	      final Set<Thread> threads = Thread.getAllStackTraces().keySet();    
	      for (Thread thread : threads) {                
	      if(thread.getName().equals("backgroundTask")){  
	           synchronized (this) {    
	             try {    
	                thread.stop();    
	                thread.interrupted();
	                  return;  
	             } catch (Exception e) {    
	             }    
	        }    
	    }    
	  }
	}

}
