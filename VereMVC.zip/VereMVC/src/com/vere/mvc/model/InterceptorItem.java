package com.vere.mvc.model;

import java.util.concurrent.ConcurrentHashMap;

public class InterceptorItem {
	private String name;
	private String clazz;
	private ConcurrentHashMap<String,InterceptorActionItem> interceptorActionItemMap;
	
	public String getName() {
		if(this.name==null)
			this.name="";
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClazz() {
		if(this.clazz==null)
			this.clazz="";
		return clazz;
	}
	public void setClazz(String clazz) {
		this.clazz = clazz;
	}
	public ConcurrentHashMap<String, InterceptorActionItem> getInterceptorActionItemMap() {
		return interceptorActionItemMap;
	}
	public void setInterceptorActionItemMap(
			ConcurrentHashMap<String, InterceptorActionItem> interceptorActionItemMap) {
		this.interceptorActionItemMap = interceptorActionItemMap;
	}
	
	
}
