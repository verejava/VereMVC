package com.vere.mvc.model;

import java.io.File;

public class CFileItem {
	
	private String fieldName;
	private File file;
	
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}
	
	

}
