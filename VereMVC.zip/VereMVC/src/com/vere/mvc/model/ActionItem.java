package com.vere.mvc.model;

import java.util.concurrent.ConcurrentHashMap;

public class ActionItem {
	private String name;
	private String clazz;
	private ConcurrentHashMap<String,ResultItem> resultItemMap;
	
	public String getName() {
		if(this.name==null)
			this.name="";
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClazz() {
		if(this.clazz==null)
			this.clazz="";
		return clazz;
	}
	public void setClazz(String clazz) {
		this.clazz = clazz;
	}
	public ConcurrentHashMap<String, ResultItem> getResultItemMap() {
		return resultItemMap;
	}
	public void setResultItemMap(ConcurrentHashMap<String, ResultItem> resultItemMap) {
		this.resultItemMap = resultItemMap;
	}
	
	
	
	
	
	
}
