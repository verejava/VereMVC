package com.vere.mvc.model;

public class ResultItem {
	private String name;
	private String type;
	private String path;
	
	public String getName() {
		if(this.name==null)
			this.name="";
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		if(this.type==null)
			this.type="";
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPath() {
		if(this.path==null)
			this.path="";
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
	
}
