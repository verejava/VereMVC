package com.vere.mvc.model;

public class InterceptorActionItem {
	private String name;
	
	public String getName() {
		if(this.name==null)
			this.name="";
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
