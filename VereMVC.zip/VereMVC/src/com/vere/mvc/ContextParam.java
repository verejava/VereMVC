package com.vere.mvc;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vere.mvc.model.CFileItem;
import com.vere.mvc.util.CFileUpload;

public class ContextParam {
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	private CFileUpload fileUpload;
	private String localeLanguage;
	private List<CFileItem> fileList=new ArrayList<CFileItem>();
	private String methodName;
	private String actionName;
	private String actionClass;
	
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	public HttpServletResponse getResponse() {
		return response;
	}
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	public CFileUpload getFileUpload() {
		return fileUpload;
	}
	public void setFileUpload(CFileUpload fileUpload) {
		this.fileUpload = fileUpload;
	}
	
	public String getLocaleLanguage() {
		return localeLanguage;
	}
	public void setLocaleLanguage(String localeLanguage) {
		this.localeLanguage = localeLanguage;
	}
	public List<CFileItem> getFileList() {
		return fileList;
	}
	public void setFileList(List<CFileItem> fileList) {
		this.fileList = fileList;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public String getActionName() {
		return actionName;
	}
	public void setActionName(String actionName) {
		this.actionName = actionName;
	}
	public String getActionClass() {
		return actionClass;
	}
	public void setActionClass(String actionClass) {
		this.actionClass = actionClass;
	}

}
