package com.vere.mvc;

import com.vere.mvc.i18.I18;
import com.vere.mvc.util.CConfig;

public class BackgroundTask extends Thread {
	
	private static boolean isRun=true;
	
	public BackgroundTask()
	{
	}

	@Override
	public void run() {
		
		while(isRun)
		{
			
			try {
				
				
				CConfig.loadResources();
				
				I18.loadResources();
				
				long reLoadConfigXmlTime=Long.parseLong(CConfig.getReLoadConfigXmlTime());
				
				Thread.sleep(reLoadConfigXmlTime);
				
			} catch (InterruptedException e) {
			}
			
			
		}
		
	}

	public static boolean isRun() {
		return isRun;
	}

	public static void setRun(boolean isRun) {
		BackgroundTask.isRun = isRun;
	}

	

}
