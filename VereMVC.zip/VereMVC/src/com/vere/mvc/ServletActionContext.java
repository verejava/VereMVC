package com.vere.mvc;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vere.mvc.model.CFileItem;
import com.vere.mvc.util.CFileUpload;

public class ServletActionContext {
	
	private static  ThreadLocal bundleHolder=new ThreadLocal(); 
	
	public static void setContextParam(ContextParam contextParam){  
    	bundleHolder.set(contextParam);  
    }  
	
	 public static ContextParam getContextParam(){  
	        return (ContextParam) bundleHolder.get();  
	    }  
	
	public static HttpServletRequest getRequest()
	{
		return getContextParam().getRequest();
	}
	
	public static HttpServletResponse getResponse()
	{
		return getContextParam().getResponse();
	}
	
	public static CFileUpload getFileUpload()
	{
		return getContextParam().getFileUpload();
	}
	
	public static List<CFileItem> getFileList()
	{
		return getContextParam().getFileList();
	}
	
	public String getMethodName() {
		return getContextParam().getMethodName();
	}
	
	public String getActionName() {
		return getContextParam().getActionName();
	}
	
	public String getActionClass() {
		return getContextParam().getActionClass();
	}
	

	public static void clearContextParam(){  
		if(bundleHolder!=null)
		{
			bundleHolder.remove();
		}
    }  
	
	public static void clearThreadLocal()
	{
		if(bundleHolder!=null)
		{
			bundleHolder.remove();
			bundleHolder=null;
		}
		
	}
}
