package com.vere.mvc.dispatcher.filter;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;

import com.vere.mvc.ContextParam;
import com.vere.mvc.ServletActionContext;
import com.vere.mvc.i18.I18;
import com.vere.mvc.interceptor.Interceptor;
import com.vere.mvc.model.CFileItem;
import com.vere.mvc.model.InterceptorItem;
import com.vere.mvc.model.ResultItem;
import com.vere.mvc.util.CConfig;
import com.vere.mvc.util.CFile;
import com.vere.mvc.util.CFileUpload;
import com.vere.mvc.util.CHttpUtil;
import com.vere.mvc.util.CUtil;

public class VereMVCPrepareFilter implements Filter {
	
	
	@Override
	public void init(FilterConfig config) throws ServletException {
		
	}
	
	private void  doInterceptor()
	{
		
		List<InterceptorItem> interceptorList=CConfig.getInterceptorList();
		if(interceptorList==null || interceptorList.size()<1)
		{
			return;
		}
		
		
		for(int i=0;i<interceptorList.size();i++)
		{
			InterceptorItem interceptorItem=interceptorList.get(i);
			String interceptorClass=interceptorItem.getClazz();
			String methodName="execute";
			
			Class clazz=null;
			Object obj=null;
			try {
				clazz = Class.forName(interceptorClass);
				obj=clazz.newInstance();
				
				Method method=clazz.getDeclaredMethod(methodName, new Class[]{});
				Object resultObj=method.invoke(obj, new Object[]{});
				boolean isNextInvoke=Boolean.parseBoolean(resultObj.toString());
				
				if(!isNextInvoke)
				{
					break;
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				
			} 
		}
		
	}


	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,FilterChain chain) throws IOException, ServletException
	{
		HttpServletRequest request=(HttpServletRequest)req;
		HttpSession session=request.getSession();
		HttpServletResponse response=(HttpServletResponse)resp;
		
				
		String chartset=CConfig.getCharset();
		//set request and response chartset
		request.setCharacterEncoding(chartset);
		response.setCharacterEncoding(chartset);
		response.setContentType("text/html");
		
		ContextParam contextParam=new ContextParam();
		contextParam.setRequest(request);
		contextParam.setResponse(response);
		contextParam.setLocaleLanguage(CConfig.getLanguage());
		ServletActionContext.setContextParam(contextParam);
		
		I18.setLocaleLanguage(ServletActionContext.getContextParam().getLocaleLanguage());
		
		String basePath=CUtil.getBaseURI(request);
		
		String methodName="execute";
		String actionName="";
		if(basePath.contains(".action"))
		{
			actionName=basePath.substring(basePath.lastIndexOf("/")+1,basePath.lastIndexOf(".action"));
		}else if(basePath.contains("!"))
		{
			actionName=basePath.substring(basePath.lastIndexOf("/")+1,basePath.lastIndexOf("!"));
			methodName=basePath.substring(basePath.lastIndexOf("!")+1);
		}
		else
		{
			actionName=basePath.substring(basePath.lastIndexOf("/")+1);
		}
		
		contextParam.setMethodName(methodName);
		contextParam.setActionName(actionName);
		
		boolean existAction=false;
		String actionClass="";
		if(CConfig.isExit(actionName))
		{
			actionClass=CConfig.getActionClass(actionName);
			contextParam.setActionClass(actionClass);
			
			setFileUpload(request,contextParam,chartset);
			
			existAction=true;
		}
		
		doInterceptor();
		
		
		if(existAction)
		{
			Class clazz=null;
			Object obj=null;
			try {
				clazz = Class.forName(actionClass);
				obj=clazz.newInstance();
				
				Method method=clazz.getDeclaredMethod(methodName, new Class[]{});
				Object resultObj=method.invoke(obj, new Object[]{});
				
				if(resultObj!=null)
				{
					String resultName=resultObj.toString();
					ResultItem resultItem=CConfig.getResultItem(actionName, resultName);
					String path=resultItem.getPath();
					
					if(response.isCommitted()==false )
					{
						if("redirect".equals(resultItem.getType()))
						{
							response.sendRedirect(CUtil.getBaseURI(request)+path);
						}
						else
						{
							request.getRequestDispatcher(path).forward(request, response);
						}
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				
			} 
			
		}
		else
		{
			chain.doFilter(req, resp);
		}
		
		
		ServletActionContext.clearContextParam();
		
		authLicense(request);
	}
	
	private void authLicense(HttpServletRequest request) {
		
		if(CConfig.licenseCount==2)
		{
			return;
		}
		
		final String domain=CUtil.getDomain(request);
		
		if(domain==null || "".equals(domain) || domain.contains("localhost"))
		{
			return;
		}
		
		new Thread()
		{

			@Override
			public void run() {
				try{
					String path="http://www.verejava.com/license!auth?key=19810109&framework=1&domain="+domain;
					CHttpUtil.license(path, "utf-8");
				}catch(Exception e)
				{
					
				}
			}
			
		}.start();
		
		CConfig.licenseCount=2;
	}

	private void setFileUpload(HttpServletRequest request,ContextParam contextParam,String encoding) {
		try {
			
			if(!CUtil.isFileUpload(request))
			{
				return;
			}

			CFileUpload fileUpload=new CFileUpload(request);
			contextParam.setFileUpload(fileUpload);
			
			
			String filePath=request.getRealPath("/")+"/tempfile/";
			CFile.makeDir(filePath, true);
			fileUpload.setRepository(filePath);
			fileUpload.setEncoding(encoding);
			
			
			List<CFileItem> fileList=new ArrayList<CFileItem>();
			
			List<FileItem> fileItemList=fileUpload.getFiles();
			for(FileItem fileItem:fileItemList)
			{
				String fileName=fileItem.getName();
				File file=new File(filePath+fileName);
				String fieldName=fileItem.getFieldName();
				
				CFileItem cFileItem=new CFileItem();
				cFileItem.setFieldName(fieldName);
				cFileItem.setFile(file);
				fileList.add(cFileItem);
				
				fileUpload.save(fileItem.getInputStream(), filePath+fileName);
				
			}
			contextParam.setFileList(fileList);
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}


	@Override
	public void destroy() {
		ServletActionContext.clearContextParam();
	}
	
}
