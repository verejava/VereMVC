package com.vere.mvc.interceptor;

public interface Interceptor {
	
	public boolean execute();
	
}
